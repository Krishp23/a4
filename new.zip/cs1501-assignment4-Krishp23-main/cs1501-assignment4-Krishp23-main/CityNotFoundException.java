final public class CityNotFoundException extends Exception {
  public CityNotFoundException(String s){
    super(s);
  }
}
